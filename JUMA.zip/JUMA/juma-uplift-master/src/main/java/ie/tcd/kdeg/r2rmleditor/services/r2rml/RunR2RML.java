package ie.tcd.kdeg.r2rmleditor.services.r2rml;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.commons.io.FileUtils;
//import org.apache.jena.rdf.model.Model;
//import org.apache.jena.rdf.model.ModelFactory;
//
//import r2rml.engine.Configuration;
//import r2rml.engine.R2RMLException;
//import r2rml.engine.R2RMLProcessor;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;

import r2rml.engine.Configuration;
import r2rml.engine.R2RMLProcessor;

public class RunR2RML {
	
	// Test class
	public static void main(String[] args) throws IOException {
		// get mapping from webpage, save it to file, run, and show in popup
		
		
		Configuration configuration = new Configuration();
		configuration.setUser("root");
		configuration.setPassword("password");
		configuration.setConnectionURL("jdbc:mysql://localhost:3306/r2rmleditor");
		configuration.setMappingFile("/Users/ademar/Desktop/r2rml-use-cases/mapping18.ttl");
		R2RMLProcessor engine = new R2RMLProcessor(configuration);
		engine.execute();

		Model model = engine.getDataset().getDefaultModel();

		StringWriter stringWriter = new StringWriter();
		model.write(stringWriter, "NT");
		String result = stringWriter.toString();

		System.out.print(result);

		
//		Model m1 = ModelFactory.createDefaultModel();
//		m1.read("output_part3.ttl");
//		
//		System.out.println(m1.containsAll(model));
//
//		StringWriter stringWriter = new StringWriter();
//		model.write(stringWriter, "NT");
//		String result = stringWriter.toString();
//
//		System.out.print(result);
		
	}

}
